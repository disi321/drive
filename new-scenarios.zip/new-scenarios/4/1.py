import socket

# part 1 --> Connecting a trusted computer to the network.
IP = "192.168.120.3" #VFD IP script  <--
PORTS = 65536

def write_to_file(lis):
    with open("./port_list.txt", "w") as f:
        f.write(str(lis))

# part 4 --> Nmap scan for HMI ports.
def hmiSearch(ip):
    ports = []
    for port in range(PORTS):
        print(port)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        socket.setdefaulttimeout(0.5)

        # returns an error indicator
        result = s.connect_ex((ip, port))
        if result == 0:
            print(f"Found port: {port}")
            ports.append(port)
    print(ports)
    return ports


write_to_file(hmiSearch(IP))
